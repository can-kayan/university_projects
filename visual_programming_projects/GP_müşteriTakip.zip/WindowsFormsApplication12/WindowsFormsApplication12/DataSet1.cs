﻿namespace WindowsFormsApplication12
{


    public partial class DataSet1
    {
        partial class Kategoriler1DataTable
        {
        }

        partial class KategorilerDataTable
        {
        }
    }
}

namespace WindowsFormsApplication12.DataSet1TableAdapters
{
    partial class ÜrünlerTableAdapter
    {
    }

    partial class MüşteriDetayları1TableAdapter
    {
    }

    partial class Müşteriler1TableAdapter
    {
    }

    partial class MüşteriDetaylarıTableAdapter
    {
    }

    partial class KategorilerTableAdapter
    {
    }

    public partial class MüşterilerTableAdapter {
    }
}
