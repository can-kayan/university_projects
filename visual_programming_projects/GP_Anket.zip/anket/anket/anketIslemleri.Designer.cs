﻿namespace anket
{
    partial class anketIslemleri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.cevapişlemi = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.soru2 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cevap1 = new System.Windows.Forms.TextBox();
            this.cevapEkle = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.cevapId = new System.Windows.Forms.Label();
            this.soru1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cevapGüncelle = new System.Windows.Forms.Button();
            this.cevap2 = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.sil = new System.Windows.Forms.Button();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.yenisoru = new System.Windows.Forms.TextBox();
            this.yenisoruEkle = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.soruId = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.soruGüncelle = new System.Windows.Forms.Button();
            this.soruGüncelleText = new System.Windows.Forms.TextBox();
            this.güncelle = new System.Windows.Forms.RadioButton();
            this.ekle = new System.Windows.Forms.RadioButton();
            this.soruişlemi = new System.Windows.Forms.RadioButton();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.panel2.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.flowLayoutPanel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1183, 329);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Right;
            this.dataGridView2.Location = new System.Drawing.Point(567, 329);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(616, 325);
            this.dataGridView2.TabIndex = 1;
            this.dataGridView2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellDoubleClick);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButton1.Location = new System.Drawing.Point(469, 57);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(56, 24);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "ekle";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.ekle_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButton2.Location = new System.Drawing.Point(469, 107);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(86, 24);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "güncelle";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // cevapişlemi
            // 
            this.cevapişlemi.AutoSize = true;
            this.cevapişlemi.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cevapişlemi.Location = new System.Drawing.Point(313, 345);
            this.cevapişlemi.Name = "cevapişlemi";
            this.cevapişlemi.Size = new System.Drawing.Size(211, 35);
            this.cevapişlemi.TabIndex = 4;
            this.cevapişlemi.Text = "cevap işlemleri";
            this.cevapişlemi.UseVisualStyleBackColor = true;
            this.cevapişlemi.CheckedChanged += new System.EventHandler(this.soruişlemi_CheckedChanged);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.flowLayoutPanel2);
            this.panel2.Controls.Add(this.radioButton2);
            this.panel2.Controls.Add(this.radioButton1);
            this.panel2.Location = new System.Drawing.Point(3, 270);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(558, 261);
            this.panel2.TabIndex = 3;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button3.Location = new System.Drawing.Point(469, 148);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 35);
            this.button3.TabIndex = 4;
            this.button3.Text = "sil";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.AutoScroll = true;
            this.flowLayoutPanel2.Controls.Add(this.panel1);
            this.flowLayoutPanel2.Controls.Add(this.panel3);
            this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(463, 261);
            this.flowLayoutPanel2.TabIndex = 3;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.soru2);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.cevap1);
            this.panel1.Controls.Add(this.cevapEkle);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(441, 237);
            this.panel1.TabIndex = 0;
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "textbox",
            "radiobutton",
            "checkbox"});
            this.comboBox1.Location = new System.Drawing.Point(12, 174);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(389, 28);
            this.comboBox1.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(11, 151);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 22);
            this.label7.TabIndex = 13;
            this.label7.Text = "cevap tipi";
            // 
            // soru2
            // 
            this.soru2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.soru2.FormattingEnabled = true;
            this.soru2.Location = new System.Drawing.Point(12, 41);
            this.soru2.Name = "soru2";
            this.soru2.Size = new System.Drawing.Size(389, 28);
            this.soru2.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(10, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 22);
            this.label3.TabIndex = 11;
            this.label3.Text = "soru";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(11, 72);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 22);
            this.label4.TabIndex = 10;
            this.label4.Text = "cevap";
            // 
            // cevap1
            // 
            this.cevap1.Location = new System.Drawing.Point(12, 94);
            this.cevap1.Multiline = true;
            this.cevap1.Name = "cevap1";
            this.cevap1.Size = new System.Drawing.Size(415, 55);
            this.cevap1.TabIndex = 9;
            // 
            // cevapEkle
            // 
            this.cevapEkle.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.cevapEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cevapEkle.Location = new System.Drawing.Point(0, 205);
            this.cevapEkle.Name = "cevapEkle";
            this.cevapEkle.Size = new System.Drawing.Size(441, 32);
            this.cevapEkle.TabIndex = 5;
            this.cevapEkle.Text = "ekle";
            this.cevapEkle.UseVisualStyleBackColor = true;
            this.cevapEkle.Click += new System.EventHandler(this.cevapEkle_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.comboBox2);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.cevapId);
            this.panel3.Controls.Add(this.soru1);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.cevapGüncelle);
            this.panel3.Controls.Add(this.cevap2);
            this.panel3.Location = new System.Drawing.Point(3, 246);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(441, 237);
            this.panel3.TabIndex = 1;
            // 
            // cevapId
            // 
            this.cevapId.AutoSize = true;
            this.cevapId.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cevapId.Location = new System.Drawing.Point(313, 11);
            this.cevapId.Name = "cevapId";
            this.cevapId.Size = new System.Drawing.Size(72, 22);
            this.cevapId.TabIndex = 9;
            this.cevapId.Text = "cevapId";
            // 
            // soru1
            // 
            this.soru1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.soru1.FormattingEnabled = true;
            this.soru1.Location = new System.Drawing.Point(14, 39);
            this.soru1.Name = "soru1";
            this.soru1.Size = new System.Drawing.Size(389, 28);
            this.soru1.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(10, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 22);
            this.label2.TabIndex = 7;
            this.label2.Text = "soru";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(8, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 22);
            this.label1.TabIndex = 6;
            this.label1.Text = "cevap";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // cevapGüncelle
            // 
            this.cevapGüncelle.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.cevapGüncelle.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cevapGüncelle.Location = new System.Drawing.Point(0, 205);
            this.cevapGüncelle.Name = "cevapGüncelle";
            this.cevapGüncelle.Size = new System.Drawing.Size(441, 32);
            this.cevapGüncelle.TabIndex = 5;
            this.cevapGüncelle.Text = "güncelle";
            this.cevapGüncelle.UseVisualStyleBackColor = true;
            this.cevapGüncelle.Click += new System.EventHandler(this.cevapGüncelle_Click);
            // 
            // cevap2
            // 
            this.cevap2.Location = new System.Drawing.Point(12, 93);
            this.cevap2.Multiline = true;
            this.cevap2.Name = "cevap2";
            this.cevap2.Size = new System.Drawing.Size(415, 55);
            this.cevap2.TabIndex = 4;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Controls.Add(this.panel4);
            this.flowLayoutPanel1.Controls.Add(this.panel2);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 386);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(567, 268);
            this.flowLayoutPanel1.TabIndex = 5;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.sil);
            this.panel4.Controls.Add(this.flowLayoutPanel3);
            this.panel4.Controls.Add(this.güncelle);
            this.panel4.Controls.Add(this.ekle);
            this.panel4.Location = new System.Drawing.Point(3, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(558, 261);
            this.panel4.TabIndex = 5;
            // 
            // sil
            // 
            this.sil.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sil.Location = new System.Drawing.Point(469, 148);
            this.sil.Name = "sil";
            this.sil.Size = new System.Drawing.Size(75, 35);
            this.sil.TabIndex = 4;
            this.sil.Text = "sil";
            this.sil.UseVisualStyleBackColor = true;
            this.sil.Click += new System.EventHandler(this.sil_Click);
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.AutoScroll = true;
            this.flowLayoutPanel3.Controls.Add(this.panel5);
            this.flowLayoutPanel3.Controls.Add(this.panel6);
            this.flowLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.flowLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(463, 261);
            this.flowLayoutPanel3.TabIndex = 3;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.label6);
            this.panel5.Controls.Add(this.yenisoru);
            this.panel5.Controls.Add(this.yenisoruEkle);
            this.panel5.Location = new System.Drawing.Point(3, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(441, 237);
            this.panel5.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(8, 15);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 22);
            this.label6.TabIndex = 14;
            this.label6.Text = "soru";
            // 
            // yenisoru
            // 
            this.yenisoru.Location = new System.Drawing.Point(-3, 40);
            this.yenisoru.Multiline = true;
            this.yenisoru.Name = "yenisoru";
            this.yenisoru.Size = new System.Drawing.Size(441, 159);
            this.yenisoru.TabIndex = 13;
            // 
            // yenisoruEkle
            // 
            this.yenisoruEkle.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.yenisoruEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.yenisoruEkle.Location = new System.Drawing.Point(0, 205);
            this.yenisoruEkle.Name = "yenisoruEkle";
            this.yenisoruEkle.Size = new System.Drawing.Size(441, 32);
            this.yenisoruEkle.TabIndex = 5;
            this.yenisoruEkle.Text = "ekle";
            this.yenisoruEkle.UseVisualStyleBackColor = true;
            this.yenisoruEkle.Click += new System.EventHandler(this.yenisoruEkle_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.soruId);
            this.panel6.Controls.Add(this.label5);
            this.panel6.Controls.Add(this.soruGüncelle);
            this.panel6.Controls.Add(this.soruGüncelleText);
            this.panel6.Location = new System.Drawing.Point(3, 246);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(441, 237);
            this.panel6.TabIndex = 1;
            // 
            // soruId
            // 
            this.soruId.AutoSize = true;
            this.soruId.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.soruId.Location = new System.Drawing.Point(370, 9);
            this.soruId.Name = "soruId";
            this.soruId.Size = new System.Drawing.Size(59, 22);
            this.soruId.TabIndex = 13;
            this.soruId.Text = "soruId";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(11, 15);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 22);
            this.label5.TabIndex = 12;
            this.label5.Text = "soru";
            // 
            // soruGüncelle
            // 
            this.soruGüncelle.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.soruGüncelle.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.soruGüncelle.Location = new System.Drawing.Point(0, 205);
            this.soruGüncelle.Name = "soruGüncelle";
            this.soruGüncelle.Size = new System.Drawing.Size(441, 32);
            this.soruGüncelle.TabIndex = 5;
            this.soruGüncelle.Text = "güncelle";
            this.soruGüncelle.UseVisualStyleBackColor = true;
            this.soruGüncelle.Click += new System.EventHandler(this.soruGüncelle_Click);
            // 
            // soruGüncelleText
            // 
            this.soruGüncelleText.Location = new System.Drawing.Point(0, 40);
            this.soruGüncelleText.Multiline = true;
            this.soruGüncelleText.Name = "soruGüncelleText";
            this.soruGüncelleText.Size = new System.Drawing.Size(441, 159);
            this.soruGüncelleText.TabIndex = 4;
            // 
            // güncelle
            // 
            this.güncelle.AutoSize = true;
            this.güncelle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.güncelle.Location = new System.Drawing.Point(469, 107);
            this.güncelle.Name = "güncelle";
            this.güncelle.Size = new System.Drawing.Size(86, 24);
            this.güncelle.TabIndex = 1;
            this.güncelle.TabStop = true;
            this.güncelle.Text = "güncelle";
            this.güncelle.UseVisualStyleBackColor = true;
            // 
            // ekle
            // 
            this.ekle.AutoSize = true;
            this.ekle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ekle.Location = new System.Drawing.Point(469, 57);
            this.ekle.Name = "ekle";
            this.ekle.Size = new System.Drawing.Size(56, 24);
            this.ekle.TabIndex = 0;
            this.ekle.TabStop = true;
            this.ekle.Text = "ekle";
            this.ekle.UseVisualStyleBackColor = true;
            this.ekle.CheckedChanged += new System.EventHandler(this.ekle_CheckedChanged);
            // 
            // soruişlemi
            // 
            this.soruişlemi.AutoSize = true;
            this.soruişlemi.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.soruişlemi.Location = new System.Drawing.Point(21, 345);
            this.soruişlemi.Name = "soruişlemi";
            this.soruişlemi.Size = new System.Drawing.Size(161, 35);
            this.soruişlemi.TabIndex = 6;
            this.soruişlemi.Text = "soru işlemi";
            this.soruişlemi.UseVisualStyleBackColor = true;
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "textbox",
            "radiobutton",
            "checkbox"});
            this.comboBox2.Location = new System.Drawing.Point(15, 174);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(389, 28);
            this.comboBox2.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(14, 151);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(86, 22);
            this.label8.TabIndex = 15;
            this.label8.Text = "cevap tipi";
            // 
            // anketIslemleri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1183, 654);
            this.Controls.Add(this.soruişlemi);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.cevapişlemi);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Name = "anketIslemleri";
            this.Text = "anketIslemleri";
            this.Load += new System.EventHandler(this.anketIslemleri_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.flowLayoutPanel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.flowLayoutPanel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton cevapişlemi;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button cevapEkle;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button cevapGüncelle;
        private System.Windows.Forms.TextBox cevap2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button sil;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button yenisoruEkle;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button soruGüncelle;
        private System.Windows.Forms.TextBox soruGüncelleText;
        private System.Windows.Forms.RadioButton güncelle;
        private System.Windows.Forms.RadioButton ekle;
        private System.Windows.Forms.ComboBox soru2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox cevap1;
        private System.Windows.Forms.ComboBox soru1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox yenisoru;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton soruişlemi;
        private System.Windows.Forms.Label cevapId;
        private System.Windows.Forms.Label soruId;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label8;
    }
}