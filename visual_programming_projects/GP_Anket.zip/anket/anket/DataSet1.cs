﻿namespace anket
{


    partial class DataSet1
    {
    }
}

namespace anket.DataSet1TableAdapters {
    
    
    public partial class resultTableAdapter {
    }
}
